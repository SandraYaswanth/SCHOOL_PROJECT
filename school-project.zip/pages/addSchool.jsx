import { useForm } from 'react-hook-form';
import { useState } from 'react';

export default function AddSchool() {
  const { register, handleSubmit, formState: { errors }, reset } = useForm();
  const [message, setMessage] = useState('');
  const [uploading, setUploading] = useState(false);

  const onSubmit = async (data) => {
    try {
      setMessage('');
      // 1) Upload image first
      setUploading(true);
      const form = new FormData();
      if (data.image?.[0]) {
        form.append('image', data.image[0]);
      } else {
        setMessage('Please select an image');
        setUploading(false);
        return;
      }
      const up = await fetch('/api/upload', { method: 'POST', body: form });
      const upRes = await up.json();
      setUploading(false);
      if (!up.ok) {
        setMessage(upRes.message || 'Image upload failed');
        return;
      }

      // 2) Save record
      const payload = {
        name: data.name,
        address: data.address,
        city: data.city,
        state: data.state,
        contact: data.contact,
        email_id: data.email_id,
        image: upRes.path, // saved path like /schoolImages/xxx.jpg
      };

      const res = await fetch('/api/addSchool', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const result = await res.json();
      if (res.ok) {
        setMessage(result.message || 'Saved!');
        reset();
      } else {
        setMessage(result.message || 'Failed to save');
      }
    } catch (e) {
      console.error(e);
      setMessage('Something went wrong');
    }
  };

  return (
    <div className="container">
      <div className="header">
        <h1>Add School</h1>
        <nav className="nav">
          <a href="/showSchools">View Schools</a>
        </nav>
      </div>

      <div className="card">
        <form onSubmit={handleSubmit(onSubmit)}>
          <label>School Name</label>
          <input placeholder="e.g. Sunshine High School"
            {...register('name', { required: 'Name is required', minLength: { value: 2, message: 'Too short' } })} />
          {errors.name && <div className="error">{errors.name.message}</div>}

          <label>Address</label>
          <input placeholder="Street, Area"
            {...register('address', { required: 'Address is required' })} />
          {errors.address && <div className="error">{errors.address.message}</div>}

          <label>City</label>
          <input placeholder="City"
            {...register('city', { required: 'City is required' })} />
          {errors.city && <div className="error">{errors.city.message}</div>}

          <label>State</label>
          <input placeholder="State"
            {...register('state', { required: 'State is required' })} />
          {errors.state && <div className="error">{errors.state.message}</div>}

          <label>Contact Number</label>
          <input type="tel" placeholder="10-digit number"
            {...register('contact', {
              required: 'Contact is required',
              pattern: { value: /^[0-9]{10}$/, message: 'Enter 10 digits' }
            })} />
          {errors.contact && <div className="error">{errors.contact.message}</div>}

          <label>Email</label>
          <input type="email" placeholder="school@example.com"
            {...register('email_id', {
              required: 'Email is required',
              pattern: { value: /^[^\s@]+@[^\s@]+\.[^\s@]+$/, message: 'Invalid email' }
            })} />
          {errors.email_id && <div className="error">{errors.email_id.message}</div>}

          <label>School Image</label>
          <input type="file" accept="image/*" {...register('image', { required: 'Image is required' })} />
          {errors.image && <div className="error">{errors.image.message}</div>}

          <div style={{ marginTop: 16 }}>
            <button type="submit" disabled={uploading}>{uploading ? 'Uploading...' : 'Save School'}</button>
          </div>
          {message && <p style={{ marginTop: 10 }}>{message}</p>}
          <p className="small" style={{ marginTop: 8 }}>Images are stored in <code>/public/schoolImages</code>.</p>
        </form>
      </div>
    </div>
  );
}
