import { useEffect, useState } from 'react';

export default function ShowSchools() {
  const [schools, setSchools] = useState([]);

  useEffect(() => {
    (async () => {
      const res = await fetch('/api/getSchools');
      const data = await res.json();
      setSchools(Array.isArray(data) ? data : []);
    })();
  }, []);

  return (
    <div className="container">
      <div className="header">
        <h1>Schools</h1>
        <nav className="nav">
          <a href="/addSchool">Add School</a>
        </nav>
      </div>

      <div className="grid grid-cols-1 grid-cols-3">
        {schools.map((s) => (
          <div className="card" key={s.id}>
            <img className="school-image" src={s.image} alt={s.name} />
            <h3 style={{ marginTop: 8 }}>{s.name}</h3>
            <p className="small">{s.address}</p>
            <p className="small">{s.city}</p>
          </div>
        ))}
        {schools.length === 0 && (
          <div className="card">
            <p>No schools yet. Try adding one.</p>
          </div>
        )}
      </div>
    </div>
  );
}
