import fs from 'fs';
import path from 'path';
import { IncomingForm } from 'formidable';

export const config = {
  api: {
    bodyParser: false,
  },
};

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Only POST allowed' });

  const uploadDir = path.join(process.cwd(), 'public', 'schoolImages');
  try { fs.mkdirSync(uploadDir, { recursive: true }); } catch {}

  const form = new IncomingForm({ multiples: false, keepExtensions: true, uploadDir });

  form.parse(req, (err, fields, files) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Upload error', error: String(err) });
    }
    const file = files?.image;
    const f = Array.isArray(file) ? file[0] : file;
    if (!f || !f.filepath) {
      return res.status(400).json({ message: 'No file received' });
    }
    const ext = path.extname(f.originalFilename || '') || path.extname(f.filepath);
    const filename = `${Date.now()}${ext || '.jpg'}`;
    const dest = path.join(uploadDir, filename);
    try {
      fs.renameSync(f.filepath, dest);
      const publicPath = `/schoolImages/${filename}`;
      return res.status(200).json({ path: publicPath });
    } catch (e) {
      console.error(e);
      return res.status(500).json({ message: 'Save error', error: String(e) });
    }
  });
}
