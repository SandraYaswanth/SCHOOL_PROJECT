import { connectDB } from '@/lib/db';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ message: 'Only POST allowed' });
  const { name, address, city, state, contact, email_id, image } = req.body || {};

  if (!name || !address || !city || !state || !contact || !email_id || !image) {
    return res.status(400).json({ message: 'Missing required fields' });
  }

  try {
    const db = await connectDB();
    await db.execute(
      'INSERT INTO schools (name, address, city, state, contact, email_id, image) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [name, address, city, state, String(contact), email_id, image]
    );
    res.status(200).json({ message: 'School added successfully!' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'DB error', error: String(err) });
  }
}
