import { connectDB } from '@/lib/db';

export default async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ message: 'Only GET allowed' });
  try {
    const db = await connectDB();
    const [rows] = await db.execute('SELECT id, name, address, city, image FROM schools ORDER BY id DESC');
    res.status(200).json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'DB error', error: String(err) });
  }
}
