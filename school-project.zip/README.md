# School Project (Next.js + MySQL, Plain CSS)

Two pages as per assignment:
1. `addSchool.jsx` – Add a school's details via a validated form (React Hook Form). Image uploads get saved into `/public/schoolImages`.
2. `showSchools.jsx` – Display all schools like an ecommerce product listing (name, address, city, image).

## Getting Started

### 1) Install
```bash
npm install
```

### 2) Create MySQL DB & Table
```sql
CREATE DATABASE IF NOT EXISTS schoolDB;
USE schoolDB;
CREATE TABLE schools (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name TEXT NOT NULL,
  address TEXT NOT NULL,
  city TEXT NOT NULL,
  state TEXT NOT NULL,
  contact BIGINT NOT NULL,
  image TEXT NOT NULL,
  email_id VARCHAR(255) NOT NULL
);
```

### 3) Configure DB (optional via env)
Create `.env.local` at project root (or edit `lib/db.js` directly):
```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=yourpassword
DB_NAME=schoolDB
DB_PORT=3306
```

### 4) Run
```bash
npm run dev
```
Open http://localhost:3000

- Go to `/addSchool` to add a school (with image upload).
- Go to `/showSchools` to view the listing grid.

## Notes
- Image uploads are handled by a Next.js API route (`/api/upload`) using `formidable` and saved under `public/schoolImages`. The saved path (e.g., `/schoolImages/12345.jpg`) is stored in the `image` column.
- On serverless hosts like Vercel, writing files to disk at runtime is not persistent. For the assignment, local run is OK. For production, use an object storage (S3, Cloudinary) and store the returned URL in `image`.
- Plain CSS (no Tailwind). The layout is responsive with a simple grid.
