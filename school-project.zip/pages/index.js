export default function Home() {
  return (
    <div className="container">
      <div className="header">
        <h1>School Directory</h1>
        <nav className="nav">
          <a href="/addSchool">Add School</a>
          <a href="/showSchools">View Schools</a>
        </nav>
      </div>
      <div className="card">
        <p>Welcome! Use the links above to add a school or view all schools.</p>
        <p className="small">This is a demo app for an assignment: Next.js + MySQL + plain CSS.</p>
      </div>
    </div>
  );
}
